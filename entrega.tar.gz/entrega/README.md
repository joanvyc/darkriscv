

rtl:    contains the systemverilog design.
  -top entity: darksoc.v
codes:  contains the tested source codes.
